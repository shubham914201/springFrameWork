package com.mavin.shubham;

public interface Vehicle {
      void drive();
}
