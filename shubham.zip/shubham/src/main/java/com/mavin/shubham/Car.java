package com.mavin.shubham;
public class Car implements Vehicle {
      public void drive() {
    	  System.out.println("The car is running");
      }
}
