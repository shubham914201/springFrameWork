package com.mavin.shubham;
public class Bike implements Vehicle {
public void drive() {
	System.out.println("Bike is moving fast");
}
}
